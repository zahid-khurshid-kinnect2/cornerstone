@include('gallery.layouts.header')

@include('gallery.layouts.sidebar')

<div class="col-sm-8 col-md-9">
    <div class="explore_post">

        <h3> IMAGES  Gallery </h3>
        <div style="margin-right:10px;">
        <div class="col-md-4">

            <div>
                <h4 class="panel-title"><center>Earth Day</center></h4>
            </div>

            <div>
                <a class="thumbnail" href="ImageGallery.html#modal8" data-toggle="modal"><img src="http://cornerstone.pk/wp-content/uploads/2016/07/f8.jpg" class="img-responsive"><label> Album: Pakistan Zindabad</label></a>
                <div class="modal" id="modal8">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <iframe class="img-responsive" src="//embedsocial.com/facebook_album/album_photos/1588996424754998" width="750" height="1500" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0"></iframe>
            </div>

        </div>


        <div class="col-md-4">
            <div >
                <h4 class="panel-title"><center>23rd March 2016.</center></h4>
            </div>

            <a class="thumbnail" href="ImageGallery.html#modal8" data-toggle="modal"><img src="http://cornerstone.pk/wp-content/uploads/2016/07/f8.jpg" class="img-responsive"><label> Album: Pakistan Zindabad</label></a>
            <div class="modal" id="modal8">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <iframe class="img-responsive" src="//embedsocial.com/facebook_album/album_photos/1588996424754998" width="750" height="1500" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0"></iframe>


        </div>


        <div class="col-md-4">

            <div >
                <h4 class="panel-title"><center>*Cap and gown ceremony</center></h4>
            </div>

            <<a class="thumbnail" href="ImageGallery.html#modal8" data-toggle="modal"><img src="http://cornerstone.pk/wp-content/uploads/2016/07/f8.jpg" class="img-responsive"><label> Album: Pakistan Zindabad</label></a>
            <div class="modal" id="modal8">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <iframe class="img-responsive" src="//embedsocial.com/facebook_album/album_photos/1588996424754998" width="750" height="1500" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0"></iframe>

        </div>


        <div class="col-md-4">

            <div>
                <h4 class="panel-title"><center>*Video of activities</center></h4>
            </div>

            <a class="thumbnail" href="ImageGallery.html#modal8" data-toggle="modal"><img src="http://cornerstone.pk/wp-content/uploads/2016/07/f8.jpg" class="img-responsive"><label> Album: Pakistan Zindabad</label></a>
            <div class="modal" id="modal8">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <a class="thumbnail" href="ImageGallery.html#modal8" data-toggle="modal"><img src="http://cornerstone.pk/wp-content/uploads/2016/07/f8.jpg" class="img-responsive"><label> Album: Pakistan Zindabad</label></a>
                            <div class="modal" id="modal8">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <iframe class="img-responsive" src="//embedsocial.com/facebook_album/album_photos/1588996424754998" width="750" height="1500" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0"></iframe>

        </div>


        <div class="col-md-4">
            <div>
                <h4 class="panel-title"><center>Pakistan Day 2016</center></h4>
            </div>

            <a class="thumbnail" href="ImageGallery.html#modal8" data-toggle="modal"><img src="http://cornerstone.pk/wp-content/uploads/2016/07/f8.jpg" class="img-responsive"><label> Album: Pakistan Zindabad</label></a>
            <div class="modal" id="modal8">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <iframe class="img-responsive" src="//embedsocial.com/facebook_album/album_photos/1588996424754998" width="750" height="1500" frameborder="0" scrolling="yes" marginheight="0" marginwidth="0"></iframe>

        </div>

    </div>
</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div>



@include('layouts.footer')

