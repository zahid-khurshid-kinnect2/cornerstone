<div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-3">
            <div class="content_nav">
                <ul>
                    <li><a href="{{url('videos')}}">Videos</a></li>
                    <li><a href="{{url('photos')}}">Images</a></li>

                </ul>
            </div>
        </div>
