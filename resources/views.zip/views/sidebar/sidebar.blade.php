<aside>
    <div id="sidebar"  class="nav-collapse">
        <!-- sidebar menu start-->
        <ul class="nav nav-pills nav-stacked">
            <li class="sub-menu">
                <a href="{{url('events')}}" class="">
                    <span>Events</span>
                </a>

            </li>

            <li class="sub-menu">
                <a href="{{url('video')}}" class="">
                    <span>Videos</span>
                </a>
            </li>



        </ul>

        <!-- sidebar menu end-->
    </div>

</aside>
<!--sidebar end-->
