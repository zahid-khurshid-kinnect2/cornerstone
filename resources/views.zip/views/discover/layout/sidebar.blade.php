<div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-3">
            <div class="content_nav">
                <ul>
                    <li><a href="{{url('discover')}}">Elementary School</a></li>
                    <li><a href="{{url('pre-school')}}">Pre School</a></li>
                    <li><a href="{{url('middle-school')}}">Middle School</a></li>
                    <li><a href="{{url('high-school')}}">High School</a></li>
                    <li><a href="{{url('igcse')}}">IGCSE</a></li>
                    <li><a href="{{url('matriculation')}}">Matriculation</a></li>
                    <li><a href="{{url('shadow-teaching')}}">Shadow Teaching</a></li>
                    <li><a href="{{url('internship')}}">Internship</a></li>
                    
                </ul>
            </div>
        </div>


