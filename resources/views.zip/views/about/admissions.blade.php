@include('about.layouts.header')

@include('layouts.sidebar')


    <div class="col-sm-8 col-md-9">
                <div class="explore_post">
                    <h3>ADMISSIONS</h3>
                    <div class="image">
                        <img class="img-responsive" src="{{asset('public/images/explore-post.jpg')}}" alt="image">
                    </div>
                    <h3>Admissions Policy</h3>
                    <p>
                        Cornerstone School welcomes pupils of all faiths, cultures, races and family backgrounds
                    </p>
                   <style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
</style>
<h3> Process</h3>
<p>
The admissions and registrations are open throughout the academic year. Each academic year

consists of two terms. Annual exams are conducted in May/June. The admission procedure starts with

a Placement test interview. After the successful completion of the placement test, parents of the

successful candidates will be asked to collect the fee vouchers. The admission representatives are

available to help.
</p>
<h3> Student Age Criteria: </h3>
<table style="width:20%">
  <tr>
    <th><strong>Grade</strong></th>
    <th><strong>Age</strong></th> 
  </tr>
<br>
  <tr>
    <td>Play Group</td>
    <td>3+</td>
</tr>
<tr>
    <td>KG</td> 
     <td>4+</td>
</tr>
<tr>
    <td>Prep</td>
    <td>5+</td>
  </tr>
</table>

<!-- table 2 -->
<table style="width:20%">
  <tr>
    <th><strong>Grade</strong></th>
    <th><strong>Age</strong></th> 
  </tr>
<br>
  <tr>
    <td>|</td>
    <td>6+</td>
</tr>
<tr>
    <td>||</td> 
     <td>7+</td>
</tr>
<tr>
    <td>|||</td>
    <td>8+</td>
  </tr>
<tr>
    <td>|V</td>
    <td>9+</td>
  </tr>
<tr>
    <td>V</td>
    <td>10+</td>
  </tr>
</table>


<!-- table 3 -->
<table style="width:20%">
  <tr>
    <th><strong>Grade</strong></th>
    <th><strong>Age</strong></th> 
  </tr>
<br>
  <tr>
    <td>V|</td>
    <td>11+</td>
</tr>
<tr>
    <td>V||</td> 
     <td>12+</td>
</tr>
<tr>
    <td>V|||</td>
    <td>13+</td>
  </tr>
<tr>
    <td>|X</td>
    <td>14+</td>
  </tr>
<tr>
    <td>X</td>
    <td>15+</td>
  </tr>
</table>
                    
                </div>
            </div>
        </div>
    </div>
</div>

@include('layouts.footer')
