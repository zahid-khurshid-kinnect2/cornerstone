<h3>An email has been received</h3>



<p>From:{{$email}}</p>

<p>Subject:{{$subject}}</p>

<div>
    {{$bodyMessage}}
</div>
