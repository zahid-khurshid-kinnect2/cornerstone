@include('about.layouts.header')

 @include('layouts.sidebar')


            <div class="col-sm-8 col-md-9">
                <div class="explore_post">
                    <h3>FACULTY & STAFF DIRECTRY</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id diam ipsum. Sed finibus libero eget nunc dapibus, id porta ex dignissim. In et lorem et felis varius gravida eget non urna. Ut nisl lorem, pretium id orci at, posuere cursus nisi. Nulla fermentum aliquet tincidunt. Quisque vel est eleifend, vehicula risus gravida, pulvinar felis. Mauris at nisl nulla. Phasellus blandit erat eu sem suscipit, at consectetur ligula tincidunt.
                    </p>

                    <div class="search_box">
                        <h4>SEARCH BY NAME</h4>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Search Faculty Member by Name">
                        </div>
                    </div>

                    <div class="search_order">
                        <h4>SEARCH BY ALPHABETICAL ORDER</h4>

                        <ul class="search_pagination clearfix">
                            <li><a href="#">A</a></li>
                            <li><a href="#" class="active">B</a></li>
                            <li><a href="#">C</a></li>
                            <li><a href="#">D</a></li>
                            <li><a href="#">E</a></li>
                            <li><a href="#">F</a></li>
                            <li><a href="#">G</a></li>
                            <li><a href="#">H</a></li>
                            <li><a href="#">I</a></li>
                            <li><a href="#">J</a></li>
                            <li><a href="#">K</a></li>
                            <li><a href="#">L</a></li>
                            <li><a href="#">M</a></li>
                            <li><a href="#">N</a></li>
                            <li><a href="#">O</a></li>
                            <li><a href="#">P</a></li>
                            <li><a href="#">Q</a></li>
                            <li><a href="#">R</a></li>
                            <li><a href="#">S</a></li>
                            <li><a href="#">T</a></li>
                            <li><a href="#">U</a></li>
                            <li><a href="#">V</a></li>
                            <li><a href="#">W</a></li>
                            <li><a href="#">X</a></li>
                            <li><a href="#">Y</a></li>
                            <li><a href="#">Z</a></li>
                        </ul>

                        <div class="name_detail clearfix">
                            <img class="col-lg-3" src="{{asset('public/images/board_sample_img.jpg')}}" height="210" width="195" alt="image">
                            <ul class="col-lg-2">
                                <li>Name:</li>
                                <li>Position:</li>
                                <li>Departmetn:</li>
                                <li>Grade Level:</li>
                                <li>Email:</li>
                            </ul>
                            <ul class="col-lg-3">
                                <li>Bilal Ahmed</li>
                                <li>Teacher</li>
                                <li>Science</li>
                                <li>Middle</li>
                                <li>bilal@cornerstone.pk</li>
                            </ul>
                        </div>
                        <div class="name_detail clearfix">
                            <img class="col-lg-3" src="{{asset('public/images/board_sample_img.jpg')}}" height="210" width="195" alt="image">
                            <ul class="col-lg-2">
                                <li>Name:</li>
                                <li>Position:</li>
                                <li>Departmetn:</li>
                                <li>Grade Level:</li>
                                <li>Email:</li>
                            </ul>
                            <ul class="col-lg-3">
                                <li>Bilal Ahmed</li>
                                <li>Teacher</li>
                                <li>Science</li>
                                <li>Middle</li>
                                <li>bilal@cornerstone.pk</li>
                            </ul>
                        </div>
                        <div class="name_detail clearfix">
                            <img class="col-lg-3" src="{{asset('public/images/board_sample_img.jpg')}}" height="210" width="195" alt="image">
                            <ul class="col-lg-2">
                                <li>Name:</li>
                                <li>Position:</li>
                                <li>Departmetn:</li>
                                <li>Grade Level:</li>
                                <li>Email:</li>
                            </ul>
                            <ul class="col-lg-3">
                                <li>Bilal Ahmed</li>
                                <li>Teacher</li>
                                <li>Science</li>
                                <li>Middle</li>
                                <li>bilal@cornerstone.pk</li>
                            </ul>
                        </div>
                        <div class="name_detail clearfix">
                            <img class="col-lg-3" src="{{asset('public/images/board_sample_img.jpg')}}" height="210" width="195" alt="image">
                            <ul class="col-lg-2">
                                <li>Name:</li>
                                <li>Position:</li>
                                <li>Departmetn:</li>
                                <li>Grade Level:</li>
                                <li>Email:</li>
                            </ul>
                            <ul class="col-lg-3">
                                <li>Bilal Ahmed</li>
                                <li>Teacher</li>
                                <li>Science</li>
                                <li>Middle</li>
                                <li>bilal@cornerstone.pk</li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

@include('layouts.footer')
