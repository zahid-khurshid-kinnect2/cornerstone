<div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-3">
            <div class="content_nav">
                <ul>
                    <li><a href="{{url('apply')}}">Apply</a></li>
                    <li><a href="{{url('pre-school')}}">Activities</a></li>
                    <li><a href="{{url('middle-school')}}">Parent Portal</a></li>
                    <li><a href="{{url('calender')}}">Calender</a></li>

                </ul>
            </div>
        </div>


