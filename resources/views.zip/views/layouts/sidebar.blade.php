<div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-3">
            <div class="content_nav">
                <ul>
                    <li><a href="{{url('about')}}" >Welcome from the Director</a></li>
                    <li><a href="{{url('admissions')}}">Admissions</a></li>
                    <li><a href="{{url('trustees')}}">Board of Trustees</a></li>
                    <li><a href="{{url('mission')}}">Mission and Vision</a></li>
                    <li><a href="{{url('contact')}}">Contact Us</a></li>
                    <li><a href="{{url('faculty')}}">Faculty & Staff Directory</a></li>
                </ul>
            </div>
        </div>

