@include('layouts.header')


<h3> Parent Pledge Form</h3>
<img src="http://cornerstone.pk/wp-content/uploads/2016/07/CORNERSTONE-SCHOOL-parents-pledge-form-01.jpg" alt="pledge form" width="900px" height="auto" >
<a href="http://cornerstone.pk/wp-content/uploads/2016/07/pledge.pdf" download><button type="button" onclick="alert('Thank You!')">Download Form</button></a>



@include('layouts.footer')
