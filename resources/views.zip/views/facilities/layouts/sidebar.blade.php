<div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-3">
            <div class="content_nav">
                <ul>
                    <li><a href="{{url('science-lab')}}">Science Lab</a></li>
                    <li><a href="{{url('food-nutrition')}}">Food & Nutrition Lab</a></li>
                    <li><a href="{{url('pool')}}">Swimming Pool</a></li>
                    <li><a href="{{url('infirmary')}}">Infirmary</a></li>
                    <li><a href="{{url('day-care')}}">Day Care</a></li>
                    <li><a href="{{url('indoor-play')}}">Indoor Play Gym</a></li>
                    <li><a href="{{url('student-locker')}}">Student Locker</a></li>
                    <li><a href="{{url('art-room')}}">Art Room</a></li>
                    <li><a href="{{url('cafeteria')}}">Cafeteria</a></li>
                    <li><a href="{{url('ict-lab')}}">ICT Lab</a></li>
                    <li><a href="{{url('gymnasium')}}">Gymnasium</a></li>
                    <li><a href="{{url('media-room')}}">Media Room</a></li>
                    <li><a href="{{url('library')}}">Library</a></li>
                    <li><a href="{{url('transport')}}">School Transport</a></li>
                </ul>
            </div>
        </div>

