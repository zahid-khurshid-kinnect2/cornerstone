@include('facilities.layouts.header')

  @include('facilities.layouts.sidebar')


    <div class="col-sm-8 col-md-9">
        <div class="explore_post">
            <h3>Indoor Play Gym</h3>
            <div class="image">
                <img class="img-responsive" src="{{asset('public/images/explore-post.jpg')}}" alt="image">
            </div>
            <p>
                Our Indoor Play Gym is a wonderful entertainment option for us

                to offer ideal and safe environment for children to practice and

                improve their communication skills, play and interact in a safe

                environment with other children and simply have fun.</p>
                <p>

                Our gym is great fun and provides the perfect place for us to give

                our children a special treat.  Children love to play and the fun toys

                and play equipment in soft play areas are ideal.

                There are lots of fun toys and play equipment to keep children

                entertained for hours including slides, rope bridges, crawl tubes

                and more.</p>
        </div>
    </div>
</div>
</div>
</div>

@include('layouts.footer')
